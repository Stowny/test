DIC_Text_Based_Mafia
====================

Code form the textbased mafia tutorial on DIC


This is not my code, but an online repository host for dream.in.code user Denis1 regarding these tutorials:

http://www.dreamincode.net/forums/topic/184431-text-based-mafia-game-database-with-connection-part-1/
http://www.dreamincode.net/forums/topic/184585-text-based-mafia-game-register-and-forgot-pass-part-2/
http://www.dreamincode.net/forums/topic/185434-text-based-mafia-game-login-layoutdesign-part-3/
http://www.dreamincode.net/forums/topic/185749-text-based-mafia-game-usersonline-inside-game-design-part-4/
http://www.dreamincode.net/forums/topic/186694-text-based-mafia-game-staff-and-forum-part-5/
http://www.dreamincode.net/forums/topic/187071-text-based-mafia-game-viewedit-profile-and-find-player-part-6/
http://www.dreamincode.net/forums/topic/187399-text-based-mafia-game-send-message-helpdesk-part-7/
http://www.dreamincode.net/forums/topic/189569-text-based-mafia-game-viewing-inbox-css-design-part-8/
http://www.dreamincode.net/forums/topic/193631-text-based-mafia-game-banningright-menu-part-9/
http://www.dreamincode.net/forums/topic/200462-text-based-mafia-game-crimes-part-10/



